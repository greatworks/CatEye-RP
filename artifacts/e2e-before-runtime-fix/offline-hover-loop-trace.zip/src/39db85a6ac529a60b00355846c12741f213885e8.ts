import { expect, test, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

async function openDemo(page: Page) {
  await page.goto('/');
  await page.locator('.menubar').getByRole('button', { name: 'File', exact: true }).click();
  await page.locator('.dropdown-menu').getByRole('button', { name: 'Open interactive example', exact: true }).click();
  await expect(page.locator('.titlebar')).toContainText('Product workspace');
}

test('demo preview supports panel states, navigation and conditional form actions without changing the design', async ({ page }, testInfo) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await openDemo(page);
  await page.getByLabel('Zoom', { exact: true }).selectOption('0.75');
  await page.screenshot({ path: testInfo.outputPath('demo-editor.png'), fullPage: true });
  await page.getByTitle('Preview (F5)', { exact: true }).click();
  const preview = page.locator('.preview-overlay');
  await expect(preview.locator('.runtime-widget[aria-label="Page title"]')).toContainText('Good morning, Alex');
  await expect(preview.locator('.runtime-widget[aria-label="Welcome title"]')).toHaveText('Make something great.');
  await preview.locator('.runtime-widget[aria-label="Panel next"]').click();
  await expect(preview.locator('.runtime-widget[aria-label="News title"]')).toHaveText('A little more dynamic.');
  await expect(preview.locator('.runtime-widget[aria-label="Welcome title"]')).toHaveCount(0);
  await preview.locator('.runtime-widget[aria-label="Panel back"]').click();
  await expect(preview.locator('.runtime-widget[aria-label="Welcome title"]')).toBeVisible();
  await preview.locator('.runtime-widget[aria-label="New project"]').click();
  await expect(preview.locator('.preview-toolbar')).toContainText('Project details');
  await preview.locator('.runtime-widget[aria-label="Save project"]').click();
  await expect(preview.locator('.runtime-widget[aria-label="Form feedback"]')).toHaveCount(0);
  await preview.getByRole('textbox', { name: 'Project name input', exact: true }).fill('Edge test project');
  await preview.locator('.runtime-widget[aria-label="Save project"]').click();
  await expect(preview.locator('.runtime-widget[aria-label="Form feedback"]')).toContainText('Created “Edge test project”');
  await page.screenshot({ path: testInfo.outputPath('demo-preview-form.png'), fullPage: true });
  await preview.getByTitle('Restart prototype', { exact: true }).click();
  await expect(preview.locator('.preview-toolbar')).toContainText('Dashboard');
  await preview.getByRole('button', { name: 'Close preview', exact: true }).click();
  const download = page.waitForEvent('download');
  await page.getByTitle('Save', { exact: true }).click();
  const saved = testInfo.outputPath('demo-after-preview.rea.json');
  await (await download).saveAs(saved);
  const doc = JSON.parse(await readFile(saved, 'utf8'));
  expect(doc.variables.LastProject).toBeUndefined();
  const detail = doc.pages.find((item: { name: string }) => item.name === 'Project details');
  expect(detail.widgets.find((item: { name: string }) => item.name === 'Form feedback').hidden).toBe(true);
  expect(detail.widgets.find((item: { name: string }) => item.name === 'Project name input').text).toBe('');
  expect(errors).toEqual([]);
});

test('exported HTML opens from file without network and retains live interactions', async ({ page, browser }, testInfo) => {
  await openDemo(page);
  const download = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export HTML', exact: true }).click();
  const htmlFile = testInfo.outputPath('offline-prototype.html');
  await (await download).saveAs(htmlFile);
  const html = await readFile(htmlFile, 'utf8');
  expect(html).toContain('prototype-data');
  expect(html).not.toMatch(/<script[^>]+src=/i);
  const offline = await browser.newContext({ offline: true, viewport: { width: 1440, height: 1000 } });
  try {
    const exported = await offline.newPage();
    const requests: string[] = [], errors: string[] = [];
    exported.on('request', request => { if (/^https?:/.test(request.url())) requests.push(request.url()); });
    exported.on('pageerror', error => errors.push(error.message));
    await exported.goto(pathToFileURL(htmlFile).href);
    await expect(exported.locator('.widget[aria-label="Page title"]')).toContainText('Good morning, Alex');
    await expect(exported.locator('.widget[aria-label="Project list"] .repeater-row')).toHaveCount(3);
    await exported.locator('.widget[aria-label="Panel next"]').click();
    await expect(exported.locator('.widget[aria-label="News title"]')).toHaveText('A little more dynamic.');
    await exported.locator('.widget[aria-label="Project name"]').first().click();
    await expect(exported.getByRole('textbox', { name: 'Project name input', exact: true })).toBeVisible();
    await exported.getByRole('button', { name: 'Save project', exact: true }).click();
    await expect(exported.locator('.widget[aria-label="Form feedback"]')).toHaveCount(0);
    await exported.getByRole('textbox', { name: 'Project name input', exact: true }).fill('Offline project');
    await exported.getByRole('button', { name: 'Save project', exact: true }).click();
    await expect(exported.locator('.widget[aria-label="Form feedback"]')).toContainText('Created “Offline project”');
    await expect(exported.getByRole('alert')).toBeEmpty();
    await exported.screenshot({ path: testInfo.outputPath('offline-prototype.png'), fullPage: true });
    await exported.getByRole('button', { name: 'Back to dashboard', exact: true }).click();
    await expect(exported.locator('.widget[aria-label="Page title"]')).toBeVisible();
    expect(requests).toEqual([]);
    expect(errors).toEqual([]);
  } finally {
    await offline.close();
  }
});
